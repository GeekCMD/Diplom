<?php



use yii\helpers\Html;

/* @var $this yii\web\View */
$this->title = Yii::$app->params['projectName'];

?>
<div class="site-index">


</div>